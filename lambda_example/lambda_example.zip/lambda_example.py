from MovieScheduleParser import parser


def lambda_handler(event, context):

    catch_on_parser = parser.CatchOnScheduleParser('https://www.catchon.co.kr/mp/tv/exclude/ch2.co')
    schedules = catch_on_parser.get_channel_schedule()

    for schedule in schedules:
        print(schedule)

    return schedules
